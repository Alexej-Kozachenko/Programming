struct Polinom
{
    int n; // ������ ��������
    int koef[100]; // �����������
};

void value(Polinom &A , int x);

void push(Polinom &A , Polinom &B);

void show(Polinom &A , Polinom &B);

void sum(Polinom &A, Polinom &B);

void difference(Polinom &A, Polinom &B);

void multiplication(Polinom &A, Polinom &B);

void derivative(Polinom &A, int x);

void n_integral(Polinom &A, int x);

void v_integral (Polinom &A, int a, int b);

void division (Polinom &A, Polinom &B);

void inout(Polinom &A, Polinom &B, int &x , int &a, int &b, int &num);

void fshow(Polinom &A, Polinom &B);

void generate(int num);


