void testsum();
void testdifferense();
void testmultiplication();
void testdivision();
void testvalue();
void testderivative();
void testv_integral();
void testn_integral();
void ftestsum();
void ftestdifferense();
void ftestmultiplication();
void ftestdivision();
void ftestvalue();
void ftestderivative();
void ftestv_integral();
void ftestn_integral();
void fsum();
void fdifferense();
void fmultiplication();
void fdivision();
void fvalue();
void fderivative();
void fv_integral();
void fn_integral();
void fgenerate();



